Team 3:
Satyam Agrawal - 211AI044 - Simulated Annealing
Anushka Agrawal - 211AI006 - Dynamic Programming
Gulshan Goyal - 211AI017 - Firefly Algorithm

--------------------------------------------------------
--------------------------------------------------------

1. There are 3 files named - Dynamic Programming, Simulated Annealing and Firefly Algorithm
2. Dynamic Programming and Simulated Annealing are .ipynb and can be run directly
3. Firefly Algorithm has several function files.
4. For Firefly Algorithm, run "firefly_main.py"

--------------------------------------------------------
--------------------------------------------------------

I/P and O/P

- Dynamic Programming: gr17 graph is predefined input from TSP LIB
- Simulated Annealing: All the graphs are preloaded and could be used as input. Use input graph are also compatible and a model input can be give as:

Enter number of stops: 7
Enter Stop-name, X-Coordinate, Y-Coordinate a 1 2
Enter Stop-name, X-Coordinate, Y-Coordinate b 3 4
Enter Stop-name, X-Coordinate, Y-Coordinate c 2 7
Enter Stop-name, X-Coordinate, Y-Coordinate d 1 100
Enter Stop-name, X-Coordinate, Y-Coordinate e 4 6
Enter Stop-name, X-Coordinate, Y-Coordinate f 2 7
Enter Stop-name, X-Coordinate, Y-Coordinate g 9 8

OUTPUT: GRAPH 

- Firefly Algorithm: eli22 is the predefined graph used in the submitted code